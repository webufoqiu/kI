# Interview Question

+ Ad: 快来抢购，这是最大的优惠
+ Ad: 今天抢购最优惠
+ Text: 今天什么时候回家

Question: 
    S = 今天回家抢购

到底是Ad呢 还是非广告？

Pr(Ad | S) ~ Pr(Text | S)

```python
Pr(Ad | S)  = Pr(Ad | w1 w2 w3)
= 
```

```python
Pr(text | S) = Pr(Ad | w1 w2 w3)

```


#  entropy: 熵
import numpy as np
from collections import Counter
from icecream import ic
from functools import lru_cache


def pr(es):
    counter = Counter(es)

    def _wrap(e):
        return counter[e] / len(es)

    return _wrap


def entropy(elements):
    # 信息熵
    p = pr(elements)

    return -np.sum(p(e) * np.log(p(e)) for e in set(elements))


def gini(elements):
    p = pr(elements)

    return 1 - np.sum(p(e) ** 2 for e in set(elements))


pure_func = gini

ic(pure_func([1, 1, 1, 1, 1, 0]))
ic(pure_func([1, 1, 1, 1, 1, 1]))
ic(pure_func([1, 2, 3, 4, 5, 8]))
ic(pure_func([1, 2, 3, 4, 5, 9]))
ic(pure_func(['a', 'b', 'c', 'c', 'c', 'c', 'c']))
ic(pure_func(['a', 'b', 'c', 'c', 'c', 'c', 'd']))

from sklearn.datasets import load_boston
from sklearn.tree import DecisionTreeRegressor, DecisionTreeClassifier
from sklearn.model_selection import train_test_split
import numpy as np
import pandas as pd
from sklearn.metrics import r2_score


house = load_boston()
X = house.data
y = house.target


x_train, x_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=0)

tree_reg = DecisionTreeRegressor()
tree_reg.fit(x_train, y_train)

print('whole dataset train acc: {}'.format(tree_reg.score(x_train, y_train)))
print('whole dataset test acc: {}'.format(tree_reg.score(x_test, y_test)))


def random_forest(train_x, train_y, test_x, test_y, drop_n=4):
    random_features = np.random.choice(list(train_x.columns), size=len(train_x.columns)-drop_n)

    sample_x = train_x[random_features]
    sample_y = train_y

    reg = DecisionTreeRegressor()
    reg.fit(sample_x, sample_y)

    train_score = reg.score(sample_x, sample_y)
    test_score = reg.score(test_x[random_features], test_y)

    print('sub sample :: train score: {}, test score: {}'.format(train_score, test_score))

    y_predicated = reg.predict(test_x[random_features])

    return y_predicated, test_score


with_feature_names = pd.DataFrame(X)
with_feature_names.columns = house['feature_names']

x_train, x_test, y_train, y_test = train_test_split(with_feature_names, y, test_size=0.3, random_state=0)

tree_num = 4

predicates = []
for _ in range(tree_num):
    predicated, score = random_forest(x_train, y_train, x_test, y_test)
    predicates.append((predicated, score))

predicates_value = [v for v, s in predicates]
forest_scores = [s for v, s in predicates]

print('the score of forest is : {}'.format(r2_score(y_test, np.mean(predicates_value, axis=0))))

weights = np.array(forest_scores) / np.sum(forest_scores)

weights_score = np.zeros_like(np.mean(predicates_value, axis=0))

for i, v in enumerate(predicates_value):
    weights_score += v * weights[i]

print('the score of weighted forest is : {}'.format(r2_score(y_test, weights_score)))

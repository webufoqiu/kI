## ABOUT

This is a mini deep learning framework created by Kaikeba @ Beijing

## Features 

+ Define Dynamic Computing Graph
+ Define Neural Network Operator
+ Define Linear, Sigmoid, L2_loss  
+ Auto-Diff Computing 
+ Auto-Feedforward and Backward 

## Remain

+  Classification 
+  Cross-Entropy
+  CNN, RNN

## Connection 

wechat: fortymiles
Mail: minchiuan@zju.edu.cn